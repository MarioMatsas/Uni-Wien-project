INSERT INTO User (username, password, birth_date, join_date) VALUES
('doc1', 'pass1', '1980-01-01', '2020-01-01'),
('doc2', 'pass2', '1985-02-02', '2021-02-02'),
('doc3', 'pass3', '1990-03-03', '2022-03-03'),
('patient4', 'pass4', '2000-05-05', '2023-05-05'),
('patient5', 'pass5', '2000-05-05', '2023-05-05'),
('patient6', 'pass6', '2000-05-05', '2023-05-05');

INSERT INTO Doctor (SSN, username, password, name, surname, profession) VALUES
('1111', 'doc1', 'pass1', 'A', 'M', 'Cardiologist'),
('2222', 'doc2', 'pass2', 'X', 'M', 'Dermatologist'),
('3333', 'doc3', 'pass3', 'E', 'M', 'Neurologist');

INSERT INTO Patient (SSN, username, password, name, surname) VALUES
('4444', 'patient4', 'pass4', 'M', 'M'),
('5555', 'patient5', 'pass5', 'P', 'X'),
('6666', 'patient6', 'pass6', 'D', 'X');

INSERT INTO ActiveSubstance (name, max_dosage_per_month, therapeutic_class) VALUES
('Paracetamol', 3000, 'Painkiller'),
('Ibuprofen', 2400, 'Anti-inflammatory'),
('Amoxicillin', 1000, 'Antibiotic');

INSERT INTO Prescription (ID, date, status, doctor_id, patient_id) VALUES
('1', '2025-03-30', 'Active', '1111', '4444'),
('2', '2025-03-30', 'Active', '2222', '5555'),
('3', '2025-03-30', 'Active', '3333', '6666');

INSERT INTO PrescriptionLine (line_number, ID, active_substance_name, dosage, details) VALUES
(1, '1', 'Paracetamol', '500mg', 'Take twice daily'),
(1, '2', 'Ibuprofen', '400mg', 'Take three times daily'),
(1, '3', 'Amoxicillin', '250mg', 'Take once daily');