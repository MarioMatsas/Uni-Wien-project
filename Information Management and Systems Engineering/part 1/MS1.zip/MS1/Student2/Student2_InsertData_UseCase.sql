INSERT INTO Prescription (ID, date, status, doctor_id, patient_id) VALUES ('4', '2025-03-31', 'Active', '1111', '4444');
INSERT INTO PrescriptionLine (line_number, ID, active_substance_name, dosage, details) VALUES 
(1, '4', 'Paracetamol', '500mg', 'Take twice daily'),
(2, '4', 'Ibuprofen', '200mg', 'Take once daily');