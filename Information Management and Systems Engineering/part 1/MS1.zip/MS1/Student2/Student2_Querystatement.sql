SELECT 
    D.SSN AS Doctor_SSN,
    COUNT(DISTINCT P.ID) AS Total_Prescriptions,
    COUNT(PL.line_number) AS Total_PrescriptionLines
FROM Doctor D
JOIN Prescription P ON D.SSN = P.doctor_id JOIN PrescriptionLine PL ON P.ID = PL.ID
WHERE D.SSN = '1111' 
GROUP BY D.SSN;