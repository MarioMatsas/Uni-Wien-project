-- Entities
-- User table (Superclass for Doctor & Patient)
CREATE TABLE User (
    username VARCHAR(255),
    password VARCHAR(255),
    birth_date DATE NOT NULL,
    join_date DATE NOT NULL,
    PRIMARY KEY (username, password)
);

-- Doctor table
CREATE TABLE Doctor (
    SSN VARCHAR(50) PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    surname VARCHAR(255) NOT NULL,
    profession VARCHAR(255) NOT NULL,
    FOREIGN KEY (username, password) REFERENCES User(username, password)
);

-- Patient table
CREATE TABLE Patient (
    SSN VARCHAR(50) PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    surname VARCHAR(255) NOT NULL,
    FOREIGN KEY (username, password) REFERENCES User(username, password)
);

-- ActiveSubstance table
CREATE TABLE ActiveSubstance (
    name VARCHAR(255) PRIMARY KEY,
    max_dosage_per_month INT NOT NULL,
    therapeutic_class VARCHAR(255) NOT NULL
);

-- Prescription table
CREATE TABLE Prescription (
    ID VARCHAR(50) PRIMARY KEY,
    date DATE NOT NULL,
    status VARCHAR(50) NOT NULL,
    doctor_id VARCHAR(50) NOT NULL,
    patient_id VARCHAR(50) NOT NULL,
    FOREIGN KEY (doctor_id) REFERENCES Doctor(SSN) ON DELETE CASCADE,
    FOREIGN KEY (patient_id) REFERENCES Patient(SSN) ON DELETE CASCADE
);

-- PharmaceuticalProduct table
CREATE TABLE PharmaceuticalProduct (
    name VARCHAR(255) PRIMARY KEY,
    price DECIMAL(10,2) NOT NULL,
    type VARCHAR(50) NOT NULL,
    active_substance_name VARCHAR(255) NOT NULL,
    FOREIGN KEY (active_substance_name) REFERENCES ActiveSubstance(name) ON DELETE CASCADE
);

-- PrescriptionLine (Weak Entity, depends on Prescription)
CREATE TABLE PrescriptionLine (
    line_number INT NOT NULL,
    ID VARCHAR(50) NOT NULL,
    active_substance_name VARCHAR(255) NOT NULL,
    dosage VARCHAR(255) NOT NULL,
    details TEXT,
    PRIMARY KEY (line_number, ID),
    FOREIGN KEY (ID) REFERENCES Prescription(ID) ON DELETE CASCADE,
    FOREIGN KEY (active_substance_name) REFERENCES ActiveSubstance(name) ON DELETE CASCADE
);


-- Relationships
-- Doctor examines Patients
CREATE TABLE Examine (
    doctor_id VARCHAR(50) NOT NULL,
    patient_id VARCHAR(50) NOT NULL,
    PRIMARY KEY (doctor_id, patient_id),
    FOREIGN KEY (doctor_id) REFERENCES Doctor(SSN) ON DELETE CASCADE,
    FOREIGN KEY (patient_id) REFERENCES Patient(SSN) ON DELETE CASCADE
);

-- Pharmaceutical Product have Active Substances
CREATE TABLE HaveActiveSubstance (
    pharmaceutical_product_name VARCHAR(255) NOT NULL,
    active_substance_name VARCHAR(255) NOT NULL,
    PRIMARY KEY (pharmaceutical_product_name, active_substance_name),
    FOREIGN KEY (pharmaceutical_product_name) REFERENCES PharmaceuticalProduct(name) ON DELETE CASCADE,
    FOREIGN KEY (active_substance_name) REFERENCES ActiveSubstance(name) ON DELETE CASCADE
);
-- Doctor Reports another Doctor (Unary Relationship)
CREATE TABLE Report (
    doctor_id_reporter VARCHAR(50) NOT NULL,
    doctor_id_reportee VARCHAR(50) NOT NULL,
    issue_date DATE NOT NULL,
    PRIMARY KEY (doctor_id_reporter, doctor_id_reportee),
    FOREIGN KEY (doctor_id_reporter) REFERENCES Doctor(SSN) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id_reportee) REFERENCES Doctor(SSN) ON DELETE CASCADE
);

-- Patient downloads his/her Prescription(s)
CREATE TABLE Download (
    patient_id VARCHAR(50) NOT NULL,
    prescription_id VARCHAR(50) NOT NULL,
    download_date DATE NOT NULL,
    PRIMARY KEY (patient_id, prescription_id, download_date),
    FOREIGN KEY (patient_id) REFERENCES Patient(SSN) ON DELETE CASCADE,
    FOREIGN KEY (prescription_id) REFERENCES Prescription(ID) ON DELETE CASCADE
);
