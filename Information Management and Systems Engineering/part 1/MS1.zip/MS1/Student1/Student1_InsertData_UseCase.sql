-- Adding new Download Data (executing the Use Case)
INSERT INTO Download (patient_id, prescription_id, download_date) VALUES
('222-22-2222', 'PER-003', '2024-07-14');