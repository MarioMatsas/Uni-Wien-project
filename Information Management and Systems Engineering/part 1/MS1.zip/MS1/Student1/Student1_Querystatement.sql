-- Query to generate analytics report
SELECT
    U.username AS User_Username,
    U.password AS User_Pass,
    P.SSN AS Patient_SSN,
    P.name AS Patient_Name,
    P.surname AS Patient_Surname,
    PR.ID AS Prescription_ID,
    PR.date AS Prescription_Date,
    PR.status AS Prescription_Status,
    D.SSN AS Doctor_SSN,
    D.name AS Doctor_Name,
    D.surname AS Doctor_Surname,
    D.profession AS Doctor_Profession,
    STRING_AGG(
        CONCAT(PL.line_number, ')', PL.active_substance_name, ',',PL.dosage, ',', PL.details),'; '
    ) AS Prescription_Lines,
    DL.download_date AS Download_Date
FROM Download DL
JOIN Prescription PR ON DL.prescription_id = PR.ID
JOIN Patient P ON DL.patient_id = P.SSN
JOIN Doctor D ON PR.doctor_id = D.SSN
JOIN PrescriptionLine PL ON PL.ID = PR.ID
JOIN User U ON P.username = U.username
WHERE DL.download_date BETWEEN '2024-01-01' AND '2024-12-31'
GROUP BY DL.download_date, PR.ID
ORDER BY DL.download_date DESC;