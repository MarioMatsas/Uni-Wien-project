-- User Data
INSERT INTO User (username, password, birth_date, join_date) VALUES
('doc_tom', '@1', '1975-06-15', '2020-05-12'),
('pat_sara', '@2', '1993-08-22', '2019-07-25'),
('doc_maria', '@3', '1988-11-05', '2023-09-06'),
('pat_ben', '@4', '2000-03-30', '2022-11-14'),
('doc_john', '@5', '1997-05-17', '2021-03-20'),
('pat_ryan', '@6', '1979-10-02', '2022-12-11');

-- Doctor Data
INSERT INTO Doctor (SSN, username, password, name, surname, profession) VALUES
('111-11-1111', 'doc_tom', '@1', 'Tom', 'Smith', 'Ophthalmologist'),
('333-33-3333', 'doc_maria', '@3', 'Maria', 'Müller', 'Neurologist'),
('555-55-5555', 'doc_john', '@5', 'John', 'Nova', 'Dentist');

-- Patient Data
INSERT INTO Patient (SSN, username, password, name, surname) VALUES
('222-22-2222', 'pat_sara', '@2', 'Sara', 'Taylor'),
('444-44-4444', 'pat_ben', '@4', 'Ben', 'Wilson'),
('666-66-6666', 'pat_ryan', '@6', 'Ryan', 'Philips');

-- Prescription Data
INSERT INTO Prescription (ID, date, status, doctor_id, patient_id) VALUES
('PER-001', '2024-03-10', 'Active', '111-11-1111', '222-22-2222'),
('PER-002', '2024-06-15', 'Completed', '111-11-1111', '444-44-4444'),
('PER-003', '2024-10-20', 'Active', '333-33-3333', '222-22-2222'),
('PER-004', '2025-01-03', 'Active', '555-55-5555', '444-44-4444'),
('PER-005', '2024-12-09', 'Active', '333-33-3333', '666-66-6666');

-- PrescriptionLine Data
INSERT INTO PrescriptionLine (line_number, ID, active_substance_name, dosage, details) VALUES
(1, 'PER-001', 'Atorvastatin', '10mg', 'Once daily'),
(2, 'PER-001', 'Aspirin', '75mg', 'Morning after breakfast'),
(1, 'PER-002', 'Metformin', '500mg', 'Twice daily'),
(1, 'PER-003', 'Lisinopril', '20mg', 'Once daily with lunch'),
(2, 'PER-003', 'Hydrochlorothiazide', '25mg', 'Once daily with water'),
(1, 'PER-004', 'Omeprazole', '40mg', 'Before meals'),
(1, 'PER-005', 'Simvastatin', '20mg', 'Once daily at bedtime');

-- Download Data
INSERT INTO Download (patient_id, prescription_id, download_date) VALUES
('222-22-2222', 'PER-001', '2024-10-11'),
('444-44-4444', 'PER-004', '2024-03-23'),
('666-66-6666', 'PER-005', '2024-06-07');

