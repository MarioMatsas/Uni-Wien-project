from flask import Flask, render_template, request, redirect, url_for, jsonify, session
#from domain.models import db
from pymongo import MongoClient
from datetime import date, datetime
from sqlalchemy import text
from flask_sqlalchemy import SQLAlchemy
import os
from datetime import datetime

app = Flask(__name__)
# Needed for session management
app.secret_key = os.environ.get("SECRET_KEY")

# SQL database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["USE_NOSQL"] = False  # Default is SQL
db = SQLAlchemy()
db.init_app(app)

# MongoDB
mongo_db = MongoClient(os.environ.get("MONGO_URL")).get_default_database()

with app.app_context():
    # If the tables are not already there, we create them
    with db.engine.begin() as connection:
        connection.execute(text("""
            CREATE TABLE IF NOT EXISTS User (
                SSN VARCHAR(50) PRIMARY KEY,
                username VARCHAR(255) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                birth_date DATE NOT NULL,
                join_date DATE NOT NULL
            )
        """))
        connection.execute(text("""
            CREATE TABLE IF NOT EXISTS Doctor (
                SSN VARCHAR(50) PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                surname VARCHAR(255) NOT NULL,
                profession VARCHAR(255) NOT NULL,
                FOREIGN KEY (SSN) REFERENCES User(SSN) ON DELETE CASCADE
            )
        """))
        connection.execute(text("""
            CREATE TABLE IF NOT EXISTS Patient (
                SSN VARCHAR(50) PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                surname VARCHAR(255) NOT NULL,
                FOREIGN KEY (SSN) REFERENCES User(SSN) ON DELETE CASCADE
            )
        """))
        connection.execute(text("""
            CREATE TABLE IF NOT EXISTS ActiveSubstance (
                name VARCHAR(255) PRIMARY KEY,
                max_dosage_per_month INT NOT NULL,
                therapeutic_class VARCHAR(255) NOT NULL
            )
        """))
        connection.execute(text("""
            CREATE TABLE IF NOT EXISTS PharmaceuticalProduct (
                name VARCHAR(255) PRIMARY KEY,
                price DECIMAL(10,2) NOT NULL,
                type VARCHAR(50) NOT NULL,
                active_substance_name VARCHAR(255) NOT NULL,
                FOREIGN KEY (active_substance_name) REFERENCES ActiveSubstance(name) ON DELETE CASCADE
            )
        """))
        connection.execute(text("""
            CREATE TABLE IF NOT EXISTS Prescription (
                ID VARCHAR(50) PRIMARY KEY,
                date DATE NOT NULL,
                status VARCHAR(50) NOT NULL,
                doctor_id VARCHAR(50) NOT NULL,
                patient_id VARCHAR(50) NOT NULL,
                FOREIGN KEY (doctor_id) REFERENCES Doctor(SSN) ON DELETE CASCADE,
                FOREIGN KEY (patient_id) REFERENCES Patient(SSN) ON DELETE CASCADE
            )
        """))
        connection.execute(text("""
            CREATE TABLE IF NOT EXISTS PrescriptionLine (
                line_number INT,
                ID VARCHAR(50),
                active_substance_name VARCHAR(255) NOT NULL,
                dosage VARCHAR(255) NOT NULL,
                details TEXT,
                PRIMARY KEY (line_number, ID),
                FOREIGN KEY (ID) REFERENCES Prescription(ID) ON DELETE CASCADE,
                FOREIGN KEY (active_substance_name) REFERENCES ActiveSubstance(name) ON DELETE CASCADE
            )
        """))

        #----------------------------------------------DownloadLog
        connection.execute(text("""
            CREATE TABLE IF NOT EXISTS DownloadLog (
                download_id VARCHAR(50) PRIMARY KEY,
                prescription_id VARCHAR(50) NOT NULL,
                patient_ssn VARCHAR(50) NOT NULL,
                download_timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (prescription_id) REFERENCES Prescription(ID) ON DELETE CASCADE,
                FOREIGN KEY (patient_ssn) REFERENCES Patient(SSN) ON DELETE CASCADE
            )
        """))

@app.route("/")
def main_page():
    return render_template("page1.html")

@app.route("/get-users")
def get_users():
    if not app.config["USE_NOSQL"]: 
        with db.engine.begin() as connection:
            result = connection.execute(text("SELECT SSN, username FROM User"))
            user_list = [{"ssn": row.SSN, "username": row.username} for row in result]
    else:
        doctors = list(mongo_db.doctors.find({}, {"_id": 1, "username": 1}))
        patients = list(mongo_db.patients.find({}, {"_id": 1, "username": 1}))
        user_list = [{"ssn": u["_id"], "username": u["username"]} for u in doctors + patients]
    return jsonify(user_list)

@app.route("/login-user", methods=["POST"])
def login_user():
    session.clear()

    data = request.get_json()
    selected_ssn = data.get("ssn")
    session["ssn"] = selected_ssn

    if not app.config["USE_NOSQL"]:
        with db.engine.begin() as connection:
            # Check if doctor
            result = connection.execute(
                text("SELECT 1 FROM Doctor WHERE SSN = :ssn"),
                {"ssn": selected_ssn}
            )
            doctor = result.fetchone()
            
            # Check if patient
            result = connection.execute(
                text("SELECT 1 FROM Patient WHERE SSN = :ssn"),
                {"ssn": selected_ssn}
            )
            patient = result.fetchone()
    else:
        doctor = mongo_db.doctors.find_one({"_id": selected_ssn})
        patient = mongo_db.patients.find_one({"_id": selected_ssn})

    if doctor:
        return jsonify({"redirect": url_for("create_prescription")})
    elif patient:
        return jsonify({"redirect": url_for("view_prescriptions")})

@app.route("/create-prescription")
def create_prescription():
    return render_template("page3.html")

@app.route("/view-prescriptions")
def view_prescriptions():
    return render_template("page2.html")

@app.route("/search_patient", methods=["POST"])
def search_patient():
    data = request.get_json()
    ssn = data.get("ssn")
    
    if not app.config["USE_NOSQL"]:
        with db.engine.begin() as connection:
            result = connection.execute(
                text("SELECT name, surname FROM Patient WHERE SSN = :ssn"),
                {"ssn": ssn}
            )
            patient = result.fetchone()
            if patient:
                return jsonify({
                    "found": True,
                    "name": f"{patient.name} {patient.surname}"
                })
    else:
        patient = mongo_db.patients.find_one({"_id": ssn})
        if patient:
            return jsonify({
                "found": True,
                "name": f"{patient['name']} {patient['surname']}"
            })
    return jsonify({"found": False})

@app.route("/get_substances")
def get_substances():
    if not app.config["USE_NOSQL"]:
        with db.engine.begin() as connection:
            result = connection.execute(text("SELECT name FROM ActiveSubstance"))
            substance_list = [{"name": row.name} for row in result]
    else: 
        substances = list(mongo_db.active_substances.find({}, {"_id": 1}))
        substance_list = [{"name": s["_id"]} for s in substances]
    return jsonify(substance_list)

@app.route("/create_prescription_true", methods=["POST"])
def create_prescription_true():
    data = request.get_json()
    patient_ssn = data.get("patient_ssn")
    doctor_ssn = session.get("ssn")
    
    if not app.config["USE_NOSQL"]:
        with db.engine.begin() as connection:
            result = connection.execute(
                text("SELECT ID FROM Prescription ORDER BY ID DESC LIMIT 1")
            )
            last_prescription = result.fetchone()
            new_id = str(int(last_prescription.ID) + 1) if last_prescription else "1"
    else:
        new_id = str(int(datetime.now().timestamp()))
    
    session["current_prescription"] = {
        "ID": new_id,
        "date": date.today().isoformat(),
        "status": "Draft",
        "doctor_id": doctor_ssn,
        "patient_id": patient_ssn,
        "lines": []
    }
    
    return jsonify({"prescription_id": new_id})

@app.route("/add_prescription_line", methods=["POST"])
def add_prescription_line():
    data = request.get_json()

    if not data.get("instructions") or not data.get("details"):
        return jsonify({"success": False})
    
    line = {
        "line_number": data.get("line_number"),
        "active_substance_name": data.get("substance"),
        "dosage": data.get("instructions"),
        "details": data.get("details")
    }
    
    session["current_prescription"]["lines"].append(line)
    session.modified = True
    
    return jsonify({"success": True})

@app.route("/finalize_prescription", methods=["POST"])
def finalize_prescription():    
    prescription_data = session["current_prescription"]
    doctor_ssn = prescription_data["doctor_id"]
    
    if not app.config["USE_NOSQL"]:
        with db.engine.begin() as connection:
            # Create prescription
            connection.execute(
                text("""
                    INSERT INTO Prescription (ID, date, status, doctor_id, patient_id)
                    VALUES (:id, :date, :status, :doctor_id, :patient_id)
                """),
                {
                    "id": prescription_data["ID"],
                    "date": date.fromisoformat(prescription_data["date"]),
                    "status": "Active",
                    "doctor_id": prescription_data["doctor_id"],
                    "patient_id": prescription_data["patient_id"]
                }
            )
            
            # Create lines
            for line_data in prescription_data["lines"]:
                connection.execute(
                    text("""
                        INSERT INTO PrescriptionLine (line_number, ID, active_substance_name, dosage, details)
                        VALUES (:line_number, :id, :active_substance_name, :dosage, :details)
                    """),
                    {
                        "line_number": line_data["line_number"],
                        "id": prescription_data["ID"],
                        "active_substance_name": line_data["active_substance_name"],
                        "dosage": line_data["dosage"],
                        "details": line_data["details"]
                    }
                )
    else:
        mongo_db.patients.update_one(
            {"_id": prescription_data["patient_id"]},
            {"$push": {"prescriptions": {
                "_id": prescription_data["ID"],
                "date": prescription_data["date"],
                "status": "Active",
                "doctor_id": prescription_data["doctor_id"],
                "lines": prescription_data["lines"]
            }}}
        )

        # Update doctor's prescription and line counts
        line_count = len(prescription_data["lines"])
        mongo_db.doctors.update_one(
            {"_id": doctor_ssn},
            {
                "$inc": {
                    "prescription_count": 1,
                    "line_count": line_count
                }
            }
        )
    
    session.clear()
    return jsonify({"success": True})

@app.route("/migrate-to-nosql", methods=["POST"])
def migrate_to_nosql():
    # Clear all MongoDB collections first
    mongo_db.patients.drop()
    mongo_db.doctors.drop()
    mongo_db.active_substances.drop()
    mongo_db.pharmaceutical_products.drop() # May not be needed, meh, leave for future expansion
    mongo_db.downloadlogs.drop()

    with db.engine.begin() as connection:
        # First get all prescriptions to calculate doctor counts
        pres_result = connection.execute(text("""
            SELECT p.doctor_id, COUNT(*) AS prescription_count, COALESCE(SUM(pl.line_count), 0) AS line_count
            FROM Prescription p
            LEFT JOIN (
                SELECT ID, COUNT(*) AS line_count
                FROM PrescriptionLine
                GROUP BY ID
            ) pl ON pl.ID = p.ID
            GROUP BY p.doctor_id
        """))
        doctor_counts = {row.doctor_id: {"prescription_count": row.prescription_count, "line_count": row.line_count} for row in pres_result}

        # Migrate doctors
        result = connection.execute(text("""
            SELECT d.SSN, d.name, d.surname, d.profession, u.username, u.birth_date, u.join_date
            FROM Doctor d JOIN User u ON d.SSN = u.SSN
        """))
        for row in result:
            counts = doctor_counts.get(row.SSN, {"prescription_count": 0, "line_count": 0})
            mongo_doctor = {
                "_id": row.SSN,
                "name": row.name,
                "surname": row.surname,
                "profession": row.profession,
                "username": row.username,
                "birth_date": row.birth_date.isoformat(),
                "join_date": row.join_date.isoformat(),
                "prescription_count": int(counts["prescription_count"]),
                "line_count": int(counts["line_count"])
            }
            mongo_db.doctors.insert_one(mongo_doctor)

        # Migrate patients
        result = connection.execute(text("""
            SELECT p.SSN, p.name, p.surname, u.username, u.birth_date, u.join_date
            FROM Patient p JOIN User u ON p.SSN = u.SSN
        """))
        for patient_row in result:
            # Get all prescriptions for this patient
            pres_result = connection.execute(
                text("SELECT ID, date, status, doctor_id FROM Prescription WHERE patient_id = :patient_id"),
                {"patient_id": patient_row.SSN}
            )
            mongo_prescriptions = []
            
            for pres_row in pres_result:
                # Get all lines for this prescription
                line_result = connection.execute(
                    text("""
                        SELECT line_number, active_substance_name, dosage, details
                        FROM PrescriptionLine WHERE ID = :id
                    """),
                    {"id": pres_row.ID}
                )
                mongo_lines = [{
                    "line_number": line.line_number,
                    "active_substance_name": line.active_substance_name,
                    "dosage": line.dosage,
                    "details": line.details
                } for line in line_result]
                
                mongo_prescriptions.append({
                    "_id": pres_row.ID,
                    "date": pres_row.date.isoformat(),
                    "status": pres_row.status,
                    "doctor_id": pres_row.doctor_id,
                    "lines": mongo_lines
                })
            
            mongo_patient = {
                "_id": patient_row.SSN,
                "name": patient_row.name,
                "surname": patient_row.surname,
                "username": patient_row.username,
                "birth_date": patient_row.birth_date.isoformat(),
                "join_date": patient_row.join_date.isoformat(),
                "prescriptions": mongo_prescriptions
            }
            mongo_db.patients.insert_one(mongo_patient)

        # Migrate active substances
        result = connection.execute(text("""
            SELECT name, max_dosage_per_month, therapeutic_class FROM ActiveSubstance
        """))
        for row in result:
            mongo_substance = {
                "_id": row.name,
                "max_dosage_per_month": row.max_dosage_per_month,
                "therapeutic_class": row.therapeutic_class
            }
            mongo_db.active_substances.insert_one(mongo_substance)

        # Migrate products (THE PRODUCTS ARE NOT REALLY USED IN THIS APP, HOWEVER THIS IS STILL NEEDED AS IT ALLOWS FOR FUTURE APP EXPANSION)
        result = connection.execute(text("""
            SELECT name, price, type, active_substance_name FROM PharmaceuticalProduct
        """))
        for row in result:
            mongo_product = {
                "_id": row.name,
                "price": float(row.price),
                "type": row.type,
                "active_substance_name": row.active_substance_name
            }
            mongo_db.pharmaceutical_products.insert_one(mongo_product)

        # Migrate downloads (seperate collection as they are pretty much just archive data)
        result = connection.execute(text("""
            SELECT download_id, prescription_id, patient_ssn, download_timestamp FROM DownloadLog
        """))
        for row in result:
            mongo_download = {
                "_id": row.download_id,
                "prescription_id": row.prescription_id,
                "patient_ssn": row.patient_ssn,
                "download_timestamp": row.download_timestamp
            }
            mongo_db.downloadlogs.insert_one(mongo_download)
    
    app.config["USE_NOSQL"] = True
    return jsonify({"success": True, "message": "Data migrated successfully to MongoDB"})

@app.route("/generate-data", methods=["POST"])
def generate_data():
    with db.engine.begin() as connection:
        # Clear all tables
        connection.execute(text("DELETE FROM DownloadLog"))
        connection.execute(text("DELETE FROM PrescriptionLine"))
        connection.execute(text("DELETE FROM Prescription"))
        connection.execute(text("DELETE FROM PharmaceuticalProduct"))
        connection.execute(text("DELETE FROM ActiveSubstance"))
        connection.execute(text("DELETE FROM Patient"))
        connection.execute(text("DELETE FROM Doctor"))
        connection.execute(text("DELETE FROM User"))
        
        # Insert some starting data
        connection.execute(text("""
            INSERT INTO User (SSN, username, password, birth_date, join_date) VALUES
            ("1111", "doc1", "pass1", "1980-01-01", "2020-01-01"),
            ("2222", "doc2", "pass2", "1985-02-02", "2021-02-02"),
            ("3333", "doc3", "pass3", "1990-03-03", "2022-03-03"),
            ("4444", "patient4", "pass4", "2000-05-05", "2023-05-05"),
            ("5555", "patient5", "pass5", "2000-05-05", "2023-05-05"),
            ("6666", "patient6", "pass6", "2000-05-05", "2023-05-05")
        """))
        
        connection.execute(text("""
            INSERT INTO Doctor (SSN, name, surname, profession) VALUES
            ("1111", "A", "M", "Cardiologist"),
            ("2222", "X", "M", "Dermatologist"),
            ("3333", "E", "M", "Neurologist")
        """))
        
        connection.execute(text("""
            INSERT INTO Patient (SSN, name, surname) VALUES
            ("4444", "M", "M"),
            ("5555", "P", "X"),
            ("6666", "D", "X")
        """))
        
        connection.execute(text("""
            INSERT INTO ActiveSubstance (name, max_dosage_per_month, therapeutic_class) VALUES
            ("Paracetamol", 3000, "Painkiller"),
            ("Ibuprofen", 2400, "Anti-inflammatory"),
            ("Amoxicillin", 1000, "Antibiotic")
        """))
        
        connection.execute(text("""
            INSERT INTO Prescription (ID, date, status, doctor_id, patient_id) VALUES
            ("1", "2025-03-30", "Active", "1111", "4444"),
            ("2", "2025-03-30", "Active", "2222", "5555"),
            ("3", "2025-03-30", "Active", "3333", "6666")
        """))

        connection.execute(text("""
            INSERT INTO PharmaceuticalProduct (name, price, type, active_substance_name) VALUES
            ("Tylenol", 5.99, "Tablet", "Paracetamol"),
            ("Advil", 6.50, "Tablet", "Ibuprofen")
        """))
        
        connection.execute(text("""
            INSERT INTO PrescriptionLine (line_number, ID, active_substance_name, dosage, details) VALUES
            (1, "1", "Paracetamol", "500mg", "Take twice daily"),
            (1, "2", "Ibuprofen", "400mg", "Take three times daily"),
            (1, "3", "Amoxicillin", "250mg", "Take once daily")
        """))

        #----------------------------------------DownloadLog
        connection.execute(text("""
            INSERT INTO DownloadLog (download_id, prescription_id, patient_ssn, download_timestamp) VALUES
            ("DL1", "1", "4444", "2025-04-01 10:00:00"),
            ("DL2", "2", "5555", "2025-04-02 11:00:00"),
            ("DL3", "3", "6666", "2025-04-03 12:00:00")
        """))
    
    return jsonify({"success": True})

#--------------------------------------------------------------------------downloadlogs
@app.route("/download-prescription/<prescription_id>", methods=["GET"])
def download_prescription(prescription_id):
    try: 
        patient_ssn = session.get("ssn")
        if not patient_ssn:    #not really needed, but added to be sure in special cases
            return jsonify({"success": False, "error": "Not logged in"}), 403

        if not app.config["USE_NOSQL"]:
            with db.engine.begin() as connection:
                pres_result = connection.execute(
                    text("""SELECT * FROM Prescription WHERE ID = :id AND patient_id = :pid"""),
                    {"id": prescription_id, "pid": patient_ssn}
                )
                prescription = pres_result.fetchone()
                if not prescription:
                    return jsonify({"success": False, "error": "Prescription not found"}), 404

                lines_result = connection.execute(
                    text("""SELECT line_number, active_substance_name, dosage, details 
                            FROM PrescriptionLine WHERE ID = :id"""),
                    {"id": prescription_id}
                )
                lines = [{
                    "line_number": row.line_number,
                    "active_substance_name": row.active_substance_name,
                    "dosage": row.dosage,
                    "details": row.details
                } for row in lines_result]

                #recording the download action here for downloadlog
                download_id = f"DL-{datetime.utcnow().timestamp()}"
                connection.execute(
                    text("""INSERT INTO DownloadLog (download_id, prescription_id, patient_ssn, download_timestamp)
                            VALUES (:did, :pid, :pssn, :ts)"""),
                    {
                        "did": download_id,
                        "pid": prescription_id,
                        "pssn": patient_ssn,
                        "ts": datetime.utcnow()    #used for current date and time
                    }
                )

            #just to make sure that prescription exist for special rare cases 
            if not prescription:
                return jsonify({"success": False, "error": "Prescription not found"}), 404
            
            #SQL
            prescription_dict = {
                "id": prescription.ID,
                "date": prescription.date,
                "status": prescription.status,
                "doctor_id": prescription.doctor_id,
                "patient_id": prescription.patient_id
            }

        else:
            #finding the patient here
            patient = mongo_db.patients.find_one(
                {"_id": patient_ssn, "prescriptions._id": prescription_id},
                {"prescriptions.$": 1}
            )
            if not patient or "prescriptions" not in patient or not patient["prescriptions"]:
                return jsonify({"success": False, "error": "Prescription not found"}), 404

            prescription = patient["prescriptions"][0]
            lines = prescription.get("lines", [])

            mongo_db.downloadlogs.insert_one({
                "prescription_id": prescription_id,
                "patient_ssn": patient_ssn,
                "download_timestamp": datetime.utcnow()
            })

            mongo_db.patients.update_one(
                {"_id": patient_ssn},
                {"$inc": {"download_count": 1}}
            )

            mongo_db.patients.update_one(
                {"_id": patient_ssn},
                {"$inc": {f"download_counts.{prescription_id}": 1}},
                upsert=True
            )

            if not prescription:
                return jsonify({"success": False, "error": "Prescription not found"}), 404

            #converting to dict for NoSQL
            prescription_dict = dict(prescription)

        session["last_downloaded_prescription"] = {
            "id": prescription_id,
            "date": prescription_dict["date"],
            "status": prescription_dict["status"],
            "doctor_id": prescription_dict["doctor_id"],
            "patient_id": patient_ssn,
            "lines": lines,
            "timestamp": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")    #complex but used for formatting the timestamp correctly(only this worked somehow)
        }

        return jsonify({
            "success": True,
            "prescription": {
                "id": prescription_id,
                "date": prescription_dict["date"],
                "status": prescription_dict["status"],
                "doctor_id": prescription_dict["doctor_id"],
                "patient_id": patient_ssn,
                "lines": lines
            }
        })

    except Exception as e:
        app.logger.error(f"Error in download-prescription: {e}")
        return jsonify({"success": False, "error": "Internal server error"}), 500

@app.route("/report")
def report():
    prescription = session.get("last_downloaded_prescription")
    if not prescription:
        return "No prescription data available.", 404
    return render_template("report.html", prescription=prescription)


@app.route("/history")
def history():
    try:
        patient_ssn = session.get("ssn")
        if not patient_ssn:   #again just to be sure
            return redirect(url_for("index")) 

        if not app.config["USE_NOSQL"]:    #SQL
            with db.engine.begin() as connection:
                results = connection.execute(text("""
                    SELECT dl.download_timestamp, dl.prescription_id, pr.date, pr.status 
                    FROM DownloadLog dl
                    JOIN Prescription pr ON dl.prescription_id = pr.ID
                    WHERE dl.patient_ssn = :ssn
                    ORDER BY dl.download_timestamp DESC
                """), {"ssn": patient_ssn})
                downloads = [
                    {
                        "prescription_id": row.prescription_id,
                        "date": row.date,
                        "status": row.status,
                        "download_timestamp": row.download_timestamp.strftime("%Y-%m-%d %H:%M:%S")
                    }
                    for row in results
                ]
        else:  #NoSQL
            cursor = mongo_db.downloadlogs.find({"patient_ssn": patient_ssn}).sort("download_timestamp", -1)
            downloads = []
            for log in cursor:
                prescription = mongo_db.patients.find_one(
                    {"_id": patient_ssn, "prescriptions._id": log["prescription_id"]},
                    {"prescriptions.$": 1}
                )
                p = prescription.get("prescriptions", [{}])[0] if prescription else {}
                ts = log.get("download_timestamp")
                downloads.append({
                    "prescription_id": log["prescription_id"],
                    "date": p.get("date", "N/A"),
                    "status": p.get("status", "N/A"),
                    "download_timestamp": ts.strftime("%Y-%m-%d %H:%M:%S") if ts and hasattr(ts, "strftime") else "Unknown"
                })

        return render_template("history.html", downloads=downloads)

    except Exception as e:
        app.logger.error(f"Error in /history: {e}")
        return "Internal Server Error", 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=443, ssl_context=('/app/certs/cert.pem', '/app/certs/key.pem'), debug=True)
