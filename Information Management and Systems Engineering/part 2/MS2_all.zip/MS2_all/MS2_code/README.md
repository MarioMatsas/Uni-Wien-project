To run the program, do the following:
1.	Unzip the folder containing all the above files.
2.	Open a terminal and navigate to that folder.
3.	Run: bash generate_certs.sh
4.	Run: docker compose build --no-cache
5.	Run: docker compose up -d
6.	Everything should be set now but just to be sure, run: docker ps (you should see that 3 containers are running, one for the webservice, one for the MariaDB database and one for the MongoDB database).
7.	Finaly open your browser and go to https://localhost, you should see the application is up and running.


** IMPORTANT ** 
The script inside generate_certs.sh worked just fine inside of dabian and should work when using the cmd or powershell as well.
However if you decide to use git bash you will need to ue this script:
#!/bin/bash

mkdir -p certs

openssl req -x509 -newkey rsa:4096 \
  -keyout certs/key.pem -out certs/cert.pem \
  -days 365 -nodes -subj "//CN=localhost"

So the same but rather than "/CN=localhost" we use "//CN=localhost"