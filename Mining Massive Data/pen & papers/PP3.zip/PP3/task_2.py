import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.svm import LinearSVC

# Load the data
df = pd.read_csv("toydata_small.csv")
X = df[["x1", "x2", "x3", "x4"]].values
y = df["y"].values

# Set weight and lrs
w = np.zeros(X.shape[1]) 
learning_rates = [0.1, 0.05, 0.025, 0.01, 0.005]  # Different learning rates
regrets = []

# Hinge loss function
def hinge_loss(w, X, y):
    return np.mean(np.maximum(0, 1 - y * (X @ w)))

# Project onto the 2 ball
def project_onto_unit_ball(w):
    norm_w = np.linalg.norm(w)
    if norm_w > 1:
        w = w / norm_w 
    return w

# Update the weights
def update_weights(w, X_t, y_t, lr_t):
    if y_t * (X_t @ w) < 1:
        grad = - y_t * X_t 
        w = w - lr_t * grad  
    return w

"""
This part could be changed but since we can use sklearn i chose to find the
optimal w (w*) by training a LinearSVC.
"""
# Train an offline SVM to approximate w*
clf = LinearSVC(C=100000, max_iter=10000, fit_intercept=False)
clf.fit(X, y)
w_star = clf.coef_.flatten()

# Project w_star to the unit l2 ball
w_star = project_onto_unit_ball(w_star)
loss_star = hinge_loss(w_star, X, y)

# Train SVM with online convex programming and report regret
for lr in learning_rates:
    regret = []
    for t in range(1, X.shape[0]+1):
        lr_t = lr / np.sqrt(t)  # Anneal learning rate
        X_t, y_t = X[t-1], y[t-1]
        w = update_weights(w, X_t, y_t, lr_t)

        # Project weights onto the unit l2 ball
        w = project_onto_unit_ball(w)

        # Calculate cumulative loss and regret
        loss_t = hinge_loss(w, X, y) 
        regret.append(loss_t - loss_star)

    # Reset weights because we have multiple lrs
    w = np.zeros(X.shape[1])  
    
    regrets.append(regret)

# Final regrets
for i in range(len(learning_rates)):
    print(f"Regret for lr={learning_rates[i]}: {np.sum(regrets[i])}")

# Plot the instantaneous regret for each learning rate
plt.figure(figsize=(10, 6))
for i in range(len(learning_rates)):
    plt.plot(regrets[i], label=f"Learning rate = {learning_rates[i]}")
plt.xlabel("Sample step")
plt.ylabel("Instantaneous Regret")
plt.legend()
plt.show()

"""
The fact that the largest lr has the lowest risk and as we make
the lr smaller the risk increses shows that we should start with a bit of a higher lr, 
because if we start with a small one, using annealing we will we soon reach
a point where the learning rate is so small, that we can hardly even learn anything.
(this is best seen with lr=0.001, where the learning curve is almost flat). Of cource,
if we make the learning rate too big like 0.5 or 1 then we will get a really bad result because
the regret will be going up and down due to the gradient going from one side of the 
minimum to the other. 
"""
