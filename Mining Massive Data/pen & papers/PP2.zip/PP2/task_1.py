import numpy as np
from sklearn import metrics
import scipy.spatial
import scipy.sparse
from matplotlib import pyplot as plt
import h5py
from tqdm import tqdm

def jaccard_similarity(X):
    """
    Computes the Jaccard similarity of matrix X of size n x d,
    where n is the number of samples and d the dimensionality of
    the samples.
    """
    # compute interesction
    intersection = (X @ X.T)

    # cardinalities of vectors
    cardinalities = intersection.diagonal()

    # Compute union using |A u B| = |A| + |B| - |A n B|
    unions = cardinalities[:,None] + cardinalities - intersection

    return intersection / unions


if __name__ == "__main__":
    # load data
    f = h5py.File("data.hdf5", "r")
    X_data = np.array(f['data-data']).astype('float')
    X_indices = np.array(f['data-indices'])
    X_indptr = np.array(f['data-indptr'])
    X = scipy.sparse.csr_matrix((X_data, X_indices, X_indptr))
    signature = np.array(f['signature'])
    f.close()

    # compute Jaccard similarities
    sim = np.array(jaccard_similarity(X))

    ### >> TODO
    # --- PART A ---
    sim = sim.item().toarray()
    print(sim.shape)
    errors = []
    number_of_hashes = list(np.arange(1, 10101, 100))  # 1, 10101, 100
    for i in range(1, len(number_of_hashes)):
        number_of_hashes[i] -= 1

    n_docs = signature.shape[1]  # Number of documents

    # tqdm for visual reasons
    for hash_num in tqdm(number_of_hashes):
        # We get the hash_num first rows of the signature 
        sub_signature = signature[:hash_num, :]
        # Create an array with the proper 2D shape (n_docs x n_docs)
        sub_sig_sim = np.zeros((n_docs, n_docs))

        for i in range(n_docs):
            for j in range(n_docs):
                total_same = np.sum(sub_signature[:, i] == sub_signature[:, j])
                sub_sig_sim[i, j] = total_same / hash_num

        # Calculate the sum of squared errors
        sum_squared_errors = np.sum((sub_sig_sim - sim)**2)
        errors.append(sum_squared_errors)

    plt.plot(number_of_hashes, errors)
    plt.xlabel("Number of hash functions")
    plt.ylabel("Sum of Squared Errors")
    plt.show()
    # --- PART A ---
    # --- PART B ---
    top_10_jac = np.argsort(-sim[0, :])[:10]
    top_10_sig_hashes = []
    for hash_num in tqdm(number_of_hashes):
        sub_signature = signature[:hash_num, :]
        # Create a vector with length equal to the number of documents
        sub_sig_sim = np.zeros(n_docs)
        
        # Compare document 0 with all others
        for j in range(n_docs):
            total_same = np.sum(sub_signature[:, 0] == sub_signature[:, j])
            sub_sig_sim[j] = total_same / hash_num
        
        # Get approximate top 10
        approx_top_10 = np.argsort(-sub_sig_sim)[:10]
        
        # Calculate how many match the true top 10
        correct_ones = len([1 for i in range(10) if approx_top_10[i] == top_10_jac[i]])
        top_10_sig_hashes.append(correct_ones)

    print(top_10_sig_hashes)
    # --- PART B ---

    ### << TODO