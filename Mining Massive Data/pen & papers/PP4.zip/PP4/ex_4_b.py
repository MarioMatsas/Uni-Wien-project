import pandas as pd
import xgboost as xgb
import shap
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt

df = pd.read_csv("data.csv", sep=";")

label_encoder = LabelEncoder()
df['Target'] = label_encoder.fit_transform(df['Target'])  # Dropout=0, Enrolled=1, Graduate=2

# Split features and target
X = df.drop('Target', axis=1)
y = df['Target']

# We will use only dropout and graduate, excluding enrolled
indxs = y != 1
X_binary = X[indxs]
y_binary = y[indxs].replace({0: 0, 2: 1})  # Relabel: Dropout=0, Graduate=1

X_train, X_test, y_train, y_test = train_test_split(X_binary, y_binary, test_size=0.2)

model = xgb.XGBClassifier(eval_metric='logloss')
model.fit(X_train, y_train)

# SHAP explanation
explainer = shap.Explainer(model, X_train)
shap_values = explainer(X_test)

# Dean
shap.summary_plot(shap_values.values, X_test, plot_type="dot", max_display=10, plot_size=(10, 8))

# Teacher
plt.figure(figsize=(10, 10))
student_index = 5 # Random student
shap.plots.waterfall(shap_values[student_index])

# Student
plt.figure(figsize=(10, 10))
shap.plots.bar(shap_values, max_display=10)  # Global importance
